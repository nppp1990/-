﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace test2007
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormEmpl fe = new FormEmpl();
            fe.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormDep fd = new FormDep();
            fd.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormSear fs = new FormSear();
            fs.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FormShow fs = new FormShow();
            fs.Show();
        }
    }
}
