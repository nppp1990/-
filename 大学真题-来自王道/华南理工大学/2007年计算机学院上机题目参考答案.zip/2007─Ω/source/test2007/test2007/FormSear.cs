﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace test2007
{
    public partial class FormSear : Form
    {
        public FormSear()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = string.Format("select ENAME,OFFER,employee.DNO as DNO,DNAME,response from employee,department where employee.DNO = department.DNO and ENAME = '{0}'",
                this.textBox1.Text);
            DataTable table = SqlManage.TableSelect(sql);

            this.listView1.Items.Clear();

            if (table.Rows.Count < 1)
            {
                MessageBox.Show("没有相关信息");
                return;
            }
            string[] str = new string[4];
            int offer;
            ListViewItem lvi;
            foreach (DataRow row in table.Rows)
            {
                str[0] = (string)row["ENAME"];
                offer = (int)row["OFFER"];
                str[1] = (string)row["DNO"];
                str[2] = (string)row["DNAME"];
                str[3] = (string)row["response"];
                lvi = this.listView1.Items.Add(str[0]);
                lvi.SubItems.Add(offer.ToString());
                lvi.SubItems.Add(str[1]);
                lvi.SubItems.Add(str[2]);
                lvi.SubItems.Add(str[3]);
            }
        }
    }
}
