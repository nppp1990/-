﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace test2007
{
    public partial class FormShow : Form
    {
        public FormShow()
        {
            InitializeComponent();
        }

        private void FormShow_Load(object sender, EventArgs e)
        {
            if (this.comboBox1.Items.Count > 0)
            {
                this.comboBox1.SelectedIndex = 0;
                this.dataGridView1.ReadOnly = true;
                this.dataGridView1.RowHeadersVisible = false;
                this.dataGridView1.AllowUserToAddRows = false;
                this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            }
            else
            {
                MessageBox.Show("没有可浏览的信息");
                this.Close();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "";
            if (this.comboBox1.SelectedIndex == 0)
            {
                sql = "select * from employee";
            }
            else
            {
                sql = "select * from department";
            }
            this.dataGridView1.DataSource = SqlManage.TableSelect(sql);
        }
    }
}
