﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace test2007
{
    class SqlManage
    {
        public static string cnnstring = "Server=wit;Database=test2007;Uid=sa;Pwd=123456;";
        public static SqlConnection cnn = null;

        public static void TableChange(string sql)
        {
            try
            {
                SqlCommand cmd = new SqlCommand(sql,SqlManage.cnn);
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("操作成功");
                }
                else
                {
                    MessageBox.Show("操作失败");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public static DataTable TableSelect(string sql)
        {
            try
            {
                DataTable table = new DataTable();
                SqlDataAdapter sdp = new SqlDataAdapter(sql,SqlManage.cnn);
                sdp.Fill(table);
                return table;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }
    }
}
