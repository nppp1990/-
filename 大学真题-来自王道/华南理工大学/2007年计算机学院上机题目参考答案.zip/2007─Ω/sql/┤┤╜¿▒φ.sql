use test2007
go

create table department(
DNO varchar(12) primary key,
DNAME varchar(50) not null,
response varchar(50) not null
);
create table employee(
ENO varchar(5) primary key,
ENAME varchar(50) not null,
OFFER int,
DNO varchar(12),
constraint fk_dno foreign key (DNO) references department(DNO)
);