﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace test2008
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormStudent fs = new FormStudent();
            fs.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormSearch fse = new FormSearch();
            fse.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormSta fs = new FormSta();
            fs.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
