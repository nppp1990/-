﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace test2008
{
    public partial class FormSearch : Form
    {
        public FormSearch()
        {
            InitializeComponent();
        }

        private void FormSearch_Load(object sender, EventArgs e)
        {
            this.txtAcademic.Enabled = false;
            this.txtClass.Enabled = false;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void checkBoxName_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBoxName.Checked)
            {
                this.txtName.Enabled = true;
            }
            else
            {
                this.txtName.Enabled = false;
            }
        }

        private void checkBoxClass_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBoxClass.Checked)
            {
                this.txtClass.Enabled = true;
            }
            else
            {
                this.txtClass.Enabled = false;
            }
        }

        private void checkBoxAcademic_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBoxAcademic.Checked)
            {
                this.txtAcademic.Enabled = true;
            }
            else
            {
                this.txtAcademic.Enabled = false;
            }
        }
        private bool JuedeTxt(TextBox t)
        {
            if (t.Text.Trim().Length < 1)
            {
                this.errorProvider.SetError(t,"不能为空");
                t.Focus();
                t.SelectAll();
                return false;
            }
            else
            {
                this.errorProvider.SetError(t, "");
                return true;
            }
        }
        private void txtName_TextChanged(object sender, EventArgs e)
        {
            this.JuedeTxt(this.txtName);
        }

        private void txtClass_TextChanged(object sender, EventArgs e)
        {
            this.JuedeTxt(this.txtClass);
        }

        private void txtAcademic_TextChanged(object sender, EventArgs e)
        {
            this.JuedeTxt(this.txtAcademic);
        }
        private void Display()
        {
            if (this.checkBoxName.Checked && !this.JuedeTxt(this.txtName))
            {
                return;
            }
            if (this.checkBoxClass.Checked && !this.JuedeTxt(this.txtClass))
            {
                return;
            }
            if (this.checkBoxAcademic.Checked && !this.JuedeTxt(this.txtAcademic))
            {
                return;
            }

            string sql = "select SNO,SNMAE,SSEX,SSCORE,CNAME,ANAME from Student,Class,Academic where Student.CNO = Class.CNO and Class.ANO = Academic.ANO ";
            if (this.checkBoxName.Checked)
            {
                sql += string.Format(" and SNMAE like '%{0}%'", this.txtName.Text);
            }
            if (this.checkBoxClass.Checked)
            {
                sql += string.Format(" and CNAME like '%{0}%'", this.txtClass.Text);
            }
            if (this.checkBoxAcademic.Checked)
            {
                sql += string.Format(" and ANAME like '%{0}%'", this.txtAcademic.Text);
            }
            if (this.rbtnA.Checked)
            {
                sql += " order by SNO asc";
            }
            else
            {
                sql += "order by SNO desc";
            }
            this.listView1.Items.Clear();

            DataTable table = SqlManage.TableSelect(sql);
            if (table.Rows.Count < 1)
            {
                MessageBox.Show("没有找到相关信息!");
                return;
            }

            ListViewItem lvi;
            string[] str = new string[4];
            int score;
            long no;
            foreach (DataRow row in table.Rows)
            {
                no = (long)row["SNO"];
                str[0] = (string)row["SNMAE"];
                str[1] = (string)row["ANAME"];
                str[2] = (string)row["CNAME"];
                str[3] = (string)row["SSEX"];
                score = (int)row["SSCORE"];
                lvi = this.listView1.Items.Add(no.ToString());
                lvi.SubItems.Add(str[0]);
                lvi.SubItems.Add(str[1]);
                lvi.SubItems.Add(str[2]);
                lvi.SubItems.Add(str[3]);
                lvi.SubItems.Add(score.ToString());
            }
        }
        private void btnSearch_Click(object sender, EventArgs e)
        {
            this.Display();
        }

        private void rbtnA_CheckedChanged(object sender, EventArgs e)
        {
            this.Display();
        }

        private void rbtnD_CheckedChanged(object sender, EventArgs e)
        {
            this.Display();
        }
    }
}
