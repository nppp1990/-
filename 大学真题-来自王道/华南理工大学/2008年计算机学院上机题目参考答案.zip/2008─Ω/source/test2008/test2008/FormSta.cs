﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace test2008
{
    public partial class FormSta : Form
    {
        public FormSta()
        {
            InitializeComponent();
        }

        private void DisplayAcaInfo()
        {
            string sql = "select Academic.ANO as no,sum(SSCORE) as total from Academic,Class,Student ";
            sql += " where Academic.ANO = Class.ANO and Class.CNO = Student.CNO";
            sql += " group by Academic.ANO";
            DataTable table = SqlManage.TableSelect(sql);
            string no;
            int total;
            ListViewItem lvi;
            foreach(DataRow row in table.Rows)
            {
                no = (string)row["no"];       
                total = (int)row["total"];
                lvi = this.listView1.Items.Add(no);
                lvi.SubItems.Add(total.ToString());
                
            }
            
        }
        private void DisplayClassInfo()
        {
            string sql = "select CNO,CNAME,CNUM from Class";
            DataTable table = SqlManage.TableSelect(sql);
            int no;
            string name;
            short num;
            ListViewItem lvi;
            foreach (DataRow row in table.Rows)
            {
                no = (int)row["CNO"];
                name = (string)row["CNAME"];
                num = (short)row["CNUM"];
                lvi = this.listView2.Items.Add(no.ToString());
                lvi.SubItems.Add(name);
                lvi.SubItems.Add(num.ToString());
                
            }
        }
        private void FormSta_Load(object sender, EventArgs e)
        {
            this.DisplayAcaInfo();
            this.DisplayClassInfo();
        }
    }
}
