﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace test2008
{
    public partial class FormStudent : Form
    {
        public FormStudent()
        {
            InitializeComponent();
        }

        private void btnCan_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private bool JudTxt(TextBox txt)
        {
            if (txt.Text.Trim().Length < 1)
            {
                this.errorProvider.SetError(txt,"不能为空");
                txt.Focus();
                txt.SelectAll();
                return false;
            }
            else
            {
                this.errorProvider.SetError(txt,"");
                return true;
            }
        }
        private void txtNo_TextChanged(object sender, EventArgs e)
        {
            this.JudTxt(this.txtNo);
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            this.JudTxt(this.txtName);
        }

        private bool JudNum(TextBox txt)
        {
            int a = 0;
            if (int.TryParse(txt.Text,out a))
            {
                this.errorProvider.SetError(txt,"");
                return true;
            }
            else
            {
                this.errorProvider.SetError(txt,"必须输入数字");
                return false;
            }
        }
        private void btnDel_Click(object sender, EventArgs e)
        {
            if (!this.JudTxt(this.txtNo)|| !this.JudNum(this.txtNo))
            {
                return;
            }
            string sql = string.Format("delete from Student where SNO = '{0}'",
            this.txtNo.Text);
            SqlManage.TableChange(sql);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if(!this.JudTxt(this.txtNo)||!this.JudTxt(this.txtName)||!this.JudNum(this.txtNo))
                return ;
            if(this.txtTell.Text.Trim().Length > 0&&!this.JudNum(this.txtTell))
                return ;
            if(this.txtScore.Text.Trim().Length > 0&&!this.JudNum(this.txtScore))
                return ;
            string strsex = this.rbtnM.Checked ? "男":"女";
            string sql = string.Format("insert into Student values('{0}','{1}','{2}','{3}','{4}','{5}')",
                this.txtNo.Text,this.txtName.Text,strsex,this.txtTell.Text,this.comboBox.Text,this.txtScore.Text);
            SqlManage.TableChange(sql);
        }

        private void FormStudent_Load(object sender, EventArgs e)
        {
            string sql = "select CNO from Class where 1 = 1;";
            DataTable table = new DataTable();
            table = SqlManage.TableSelect(sql);
            if (table.Rows.Count < 1)
            {
                return;
            }
            int cno;
            foreach (DataRow row in table.Rows)
            {
                cno = (int)row["CNO"];
                this.comboBox.Items.Add(cno.ToString());
            }
            this.comboBox.SelectedIndex = 0;
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            if (!this.JudTxt(this.txtNo) || !this.JudTxt(this.txtName) || !this.JudNum(this.txtNo))
                return;
            if (this.txtTell.Text.Trim().Length > 0 && !this.JudNum(this.txtTell))
                return;
            if (this.txtScore.Text.Trim().Length > 0 && !this.JudNum(this.txtScore))
                return;
            string strsex = this.rbtnM.Checked ? "男" : "女";

            string sql = string.Format("update Student set SNMAE = '{1}',SSEX = '{2}',STELL = '{3}',CNO = '{4}',SSCORE = '{5}' where SNO = '{0}'",
                this.txtNo.Text,this.txtName.Text,strsex,this.txtTell.Text,this.comboBox.Text,this.txtScore.Text);
            SqlManage.TableChange(sql);
        }
    }
}
