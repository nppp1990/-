create database SMS
