use SMS
go
create table Academic(
ANO varchar(20) primary key,
ANAME varchar(50) not null,
AADDRESS ntext,
ANUM int,
ATELL bigint
);

create table Class(
CNO int primary key,
CNAME varchar(50) not null,
CNUM smallint ,
ANO varchar(20),
constraint fk_ano foreign key (ANO) references Academic(ANO)
);

create table Student(
SNO bigint primary key,
SNMAE varchar(20) not null,
SSEX char(2) not null,
STELL bigint,
CNO int,
SSCORE int,
constraint fk_cno foreign key (CNO) references Class(CNO),
constraint fk_sex check(SSEX in ('��','Ů'))
);
