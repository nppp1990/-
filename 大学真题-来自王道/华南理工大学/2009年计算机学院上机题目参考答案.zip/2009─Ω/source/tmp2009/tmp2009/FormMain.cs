﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace tmp2009
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormNoSea fn = new FormNoSea();
            fn.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormSupply fs = new FormSupply();
            fs.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormSta fs = new FormSta();
            fs.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FormShow fs = new FormShow();
            fs.Show();
        }
    }
}
