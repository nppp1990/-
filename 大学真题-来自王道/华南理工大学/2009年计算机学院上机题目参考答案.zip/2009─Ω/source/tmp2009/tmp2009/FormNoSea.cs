﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace tmp2009
{
    public partial class FormNoSea : Form
    {
        public FormNoSea()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!SqlManage.JudTextBox(this.textBox1))
            {
                MessageBox.Show("输入订单编号");
                return;
            }
            string sql = string.Format("select OrderName as 订单名,OrderDate as 下订单日期,RequiredDate as 交付日期,Amount as 总金额 from Orders where OrderID = '{0}'",
                this.textBox1.Text);
            DataTable table1 = SqlManage.TableSelect(sql);
            this.dataGridView1.DataSource = table1;

            sql = string.Format("select ProductID as 产品编号,UnitPrice as 单价, Quantity as 数量 from OrderDetails where ProductName = '{0}'",
                this.textBox1.Text);
            DataTable table2 = SqlManage.TableSelect(sql);
            this.dataGridView2.DataSource = table2;

            if (table1.Rows.Count < 1)
            {
                MessageBox.Show("没有相关信息");
            }
        }

        private void FormNoSea_Load(object sender, EventArgs e)
        {
            SqlManage.SetDataGridView(this.dataGridView1);
            SqlManage.SetDataGridView(this.dataGridView2);
        }
    }
}
