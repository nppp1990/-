﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace tmp2009
{
    public partial class FormShow : Form
    {
        public FormShow()
        {
            InitializeComponent();
        }

        private void FormShow_Load(object sender, EventArgs e)
        {
            SqlManage.SetDataGridView(this.dataGridView1);
            this.comboBox1.SelectedIndex = 0;
            string sql = "select ProdcuctID as 产品编号,ProductName as 产品名,SupplierName as 供应商 from Products";
            DataTable table = SqlManage.TableSelect(sql);
            this.dataGridView1.DataSource = table;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "";
            if (this.comboBox1.SelectedIndex == 0)
            {
                sql = "select ProdcuctID as 产品编号,ProductName as 产品名,SupplierName as 供应商 from Products";
            }
            else if (this.comboBox1.SelectedIndex == 1)
            {
                sql = "select OrderID as 订单编号,OrderName as 订单名,OrderDate as 下订单日期,RequiredDate as 交付日期,Amount as 总金额 from Orders";
            }
            else if (this.comboBox1.SelectedIndex == 2)
            {
                sql = "select ProductName as 订单编号,ProductID as 产品编号,UnitPrice as 单价,Quantity as 数量 from OrderDetails";
            }
            else
            {
                return;
            }
            DataTable table = SqlManage.TableSelect(sql);
            this.dataGridView1.DataSource = table;
        }
    }
}
