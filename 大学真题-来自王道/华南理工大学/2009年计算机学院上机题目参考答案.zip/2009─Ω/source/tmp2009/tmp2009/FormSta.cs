﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace tmp2009
{
    public partial class FormSta : Form
    {
        public FormSta()
        {
            InitializeComponent();
        }
        private void SelectTotal()
        {
            string sql = "select OrderID as 订单编号,SUM(Quantity) as";
            sql += " 总数量 from Orders,OrderDetails where Orders.OrderID";
            sql += " = OrderDetails.ProductName group by OrderID";
            DataTable table = SqlManage.TableSelect(sql);
            this.dataGridView1.DataSource = table;

        }

        private void SelectProducts()
        {
            string sql = "select Products.ProductName as 订单名,AVG(UnitPrice) 平均单价,SUM(Quantity) ";
            sql += " as 总销售数量,MAX(UnitPrice) as 最高单价,MIN(UnitPrice) as 最低单价 from Products,";
            sql += " OrderDetails where Products.ProdcuctID = OrderDetails.ProductID group by Products.ProductName";
            DataTable table = SqlManage.TableSelect(sql);
            this.dataGridView2.DataSource = table;
        }
        private void FormSta_Load(object sender, EventArgs e)
        {
            SqlManage.SetDataGridView(this.dataGridView1);
            SqlManage.SetDataGridView(this.dataGridView2);
            this.SelectTotal();
            this.SelectProducts();
        }
    }
}
