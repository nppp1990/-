﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace tmp2009
{
    public partial class FormSupply : Form
    {
        public FormSupply()
        {
            InitializeComponent();
        }

        private void FormSupply_Load(object sender, EventArgs e)
        {
            SqlManage.SetDataGridView(this.dataGridView1);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!SqlManage.JudTextBox(this.textBox1))
            {
                MessageBox.Show("输入供应商名称");
                return;
            }
            string sql = string.Format("select Products.SupplierName as 供应商名称,OrderID as 订单编号,OrderName as 订单名称,OrderDate as 下订单日期,RequiredDate as 交付日期,Amount as 订单金额 from Products,Orders,OrderDetails where Products.ProdcuctID = OrderDetails.ProductID and OrderDetails.ProductName = Orders.OrderID and SupplierName = '{0}'",
                this.textBox1.Text);
            DataTable table = SqlManage.TableSelect(sql);
            this.dataGridView1.DataSource = table;
            if (table.Rows.Count < 1)
            {
                MessageBox.Show("没有相关订单");
            }
        }
    }
}
