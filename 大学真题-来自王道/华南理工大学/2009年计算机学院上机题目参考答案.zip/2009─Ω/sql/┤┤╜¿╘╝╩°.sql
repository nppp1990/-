use test2009

alter table OrderDetails add constraint fk_orderID foreign key (ProductName) references Orders(OrderID);
alter table OrderDetails add constraint fk_productID foreign key (ProductID) references Products(ProdcuctID);