use test2009

create table OrderDetails(
ProductName char(5),
ProductID char(5),
UnitPrice Numeric(8,2) not null,
Quantity smallint not null,
primary key(ProductName,ProductID)
);