use test2009

create table Orders(
OrderID char(5) primary key,
OrderName varchar(30) not null,
OrderDate smalldatetime not null,
RequiredDate smalldatetime,
Amount Numeric(12,2) default 0
);