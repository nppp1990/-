use test2009

create index idx_ordername on Orders(OrderName);