use test2009
go
create view ww_sttistics
as
select Products.ProductName,SUM(Quantity) as number ,sum(Amount) as total
from Products,Orders,OrderDetails
where Products.ProdcuctID = OrderDetails.ProductID and OrderDetails.ProductName = Orders.OrderID
group by Products.ProductName