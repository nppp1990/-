use tmp2009
go
create table orders(
OrderId char(5) primary key,
OrderName varchar(50) not null,
OrderData smalldatetime not null,
RequiredData smalldatetime,
Amount Numeric(10,2) default 0
);

create table OrderDetails(
OrderId char(5),
ProductId char(5),
UintPrice Numeric(8,2) not null,
Quantity smallint not null,
primary key(OrderId,ProductId)
);

create table Products(
ProductId char(5) primary key,
ProductName varchar(50) not null,
SupplierName varchar(50) not null
);

alter table OrderDetails add constraint fk_oderId foreign key (OrderId) references orders(OrderId);
alter table OrderDetails add constraint fk_productId foreign key (ProductId) references Products(ProductId);
create index idx_orderName on orders(OrderName);
go

create view ww_statistics
as
(
select SUM(Quantity) as Number,SUM(Amount) as total 
from orders,OrderDetails
where orders.OrderId = OrderDetails.OrderId
);