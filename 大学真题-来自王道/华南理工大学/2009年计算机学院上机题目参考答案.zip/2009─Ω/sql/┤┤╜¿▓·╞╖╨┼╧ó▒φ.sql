use test2009

create table Products(
ProdcuctID char(5) primary key,
ProductName varchar(50) not null,
SupplierName varchar(50) not null
);