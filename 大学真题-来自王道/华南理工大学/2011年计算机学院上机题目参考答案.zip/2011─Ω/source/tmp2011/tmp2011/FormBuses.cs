﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace tmp2011
{
    public partial class FormBuses : Form
    {
        public FormBuses()
        {
            InitializeComponent();
        }

        private void FormBuses_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (!SqlManage.JudTextBox(this.textBox1))
            {
                MessageBox.Show("输入车牌号");
                return;
            }
            string sql = string.Format("delete from buses where BNO = '{0}'",this.textBox1.Text);
            SqlManage.TableChange(sql);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!SqlManage.JudTextBox(this.textBox1))
            {
                MessageBox.Show("输入车牌号");
                return;
            }
            if (!SqlManage.JudTextBox(this.textBox2))
            {
                MessageBox.Show("输入生产厂商");
                return;
            }
            string sql = string.Format("insert into buses values('{0}','{1}')",
                this.textBox1.Text,this.textBox2.Text);
            SqlManage.TableChange(sql);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!SqlManage.JudTextBox(this.textBox1))
            {
                MessageBox.Show("输入车牌号");
                return;
            }
            if (!SqlManage.JudTextBox(this.textBox2))
            {
                MessageBox.Show("输入生产厂商");
                return;
            }
            string sql = string.Format("update buses set BCOMPANY = '{1}' where BNO = '{0}'",
                this.textBox1.Text, this.textBox2.Text);
            SqlManage.TableChange(sql);
        }
    }
}
