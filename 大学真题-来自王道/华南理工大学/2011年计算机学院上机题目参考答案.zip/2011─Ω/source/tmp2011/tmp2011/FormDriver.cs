﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace tmp2011
{
    public partial class FormDriver : Form
    {
        public FormDriver()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (!SqlManage.JudTextBox(this.textBox1))
            {
                MessageBox.Show("输入员工号");
                return;
            }
            string sql = string.Format("delete from driver where DNO = '{0}'",this.textBox1.Text);
            SqlManage.TableChange(sql);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!SqlManage.JudTextBox(this.textBox1))
            {
                MessageBox.Show("输入员工编号");
                return;
            }
            if (!SqlManage.JudTextBox(this.textBox2))
            {
                MessageBox.Show("输入姓名");
                return;
            }
            if (!SqlManage.JudTextBox(this.textBox3))
            {
                MessageBox.Show("输入年龄");
                return ;
            }
            int a = 0;
            if (!int.TryParse(this.textBox3.Text,out a))
            {
                MessageBox.Show("年龄必须是整数");
                return;
            }
            int age = int.Parse(this.textBox3.Text);
            if (!(age > 19 && age < 61))
            {
                MessageBox.Show("年龄必须在20都60之间");
                return ;
            }
            string sex = this.radioButton1.Checked ? "男":"女";
            string sql = string.Format("insert into driver values('{0}','{1}','{2}','{3}','{4}')",
                this.textBox1.Text,this.textBox2.Text,sex,this.textBox3.Text,this.textBox4.Text);
            SqlManage.TableChange(sql);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            if (!SqlManage.JudTextBox(this.textBox1))
            {
                MessageBox.Show("输入员工编号");
                return;
            }
            if (!SqlManage.JudTextBox(this.textBox2))
            {
                MessageBox.Show("输入姓名");
                return;
            }
            if (!SqlManage.JudTextBox(this.textBox3))
            {
                MessageBox.Show("输入年龄");
                return ;
            }
            int a = 0;
            if (!int.TryParse(this.textBox3.Text,out a))
            {
                MessageBox.Show("年龄必须是整数");
                return;
            }
            int age = int.Parse(this.textBox3.Text);
            if (!(age > 19 && age < 61))
            {
                MessageBox.Show("年龄必须在20都60之间");
                return ;
            }
            string sex = this.radioButton2.Checked ? "男" : "女";
            string sql = string.Format("update driver set DNAME='{1}',DSEX='{2}',DAGE='{3}',DTELL='{4}' where DNO = '{0}'",
                this.textBox1.Text, this.textBox2.Text,sex, this.textBox3.Text, this.textBox4.Text);
            SqlManage.TableChange(sql);
        }
    }
}
