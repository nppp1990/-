﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace tmp2011
{
    public partial class FormLine : Form
    {
        public FormLine()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private bool judTxt(TextBox t)
        {
            if (t.Text.Trim().Length < 1)
            {
                this.errorProvider.SetError(t,"输入正确内容");
                t.Focus();
                t.SelectAll();
                return false;
            }
            else
            {
                return true;
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (!this.judTxt(this.textBox1))
            {
                return;
            }
            string sql = string.Format("delete from buslines where LNO = '{0}'", this.textBox1.Text);
            SqlManage.TableChange(sql);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!this.judTxt(this.textBox1)||!this.judTxt(this.textBox2)||!this.judTxt(this.textBox3)||!this.judTxt(this.textBox4))
            {
                return;
            }
            uint a = 1;
            if (!uint.TryParse(this.textBox4.Text,out a))
            {
                MessageBox.Show("距离必须是正整数");
                return;
            }
            string sql = string.Format("insert into buslines values('{0}','{1}','{2}','{3}')",
                this.textBox1.Text,this.textBox2.Text,this.textBox3.Text,this.textBox4.Text);
            SqlManage.TableChange(sql);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!this.judTxt(this.textBox1) || !this.judTxt(this.textBox2) || !this.judTxt(this.textBox3) || !this.judTxt(this.textBox4))
            {
                return;
            }
            uint a = 1;
            if (!uint.TryParse(this.textBox4.Text, out a))
            {
                MessageBox.Show("距离必须是正整数");
                return;
            }
            string sql = string.Format("update buslines set LSTART = '{1}',LEND='{2}',LDISTANCE='{3}' where LNO = '{0}'",
                this.textBox1.Text,this.textBox2.Text,this.textBox3.Text,this.textBox4.Text);
            SqlManage.TableChange(sql);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (this.judTxt(this.textBox1))
            {
                this.errorProvider.SetError(this.textBox1,"");
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (this.judTxt(this.textBox2))
            {
                this.errorProvider.SetError(this.textBox2,"");
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (this.judTxt(this.textBox3))
            {
                this.errorProvider.SetError(this.textBox3,"");
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (this.judTxt(this.textBox4))
            {
                this.errorProvider.SetError(this.textBox4,"");
            }
        }
    }
}
