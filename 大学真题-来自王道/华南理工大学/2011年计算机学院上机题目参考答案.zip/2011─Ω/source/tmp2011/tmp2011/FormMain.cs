﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace tmp2011
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 点击退出应用程序时候
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        /// <summary>
        /// 点击显示所有信息时候
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnShow_Click(object sender, EventArgs e)
        {
            FormShow fs = new FormShow();
            fs.Show();
        }

        /// <summary>
        /// 点击公交表操作时候
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            FormBuses fb = new FormBuses();
            fb.Show();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormDriver fd = new FormDriver();
            fd.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormLine fl = new FormLine();
            fl.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FormTime ft = new FormTime();
            ft.Show();
        }
    }
}
