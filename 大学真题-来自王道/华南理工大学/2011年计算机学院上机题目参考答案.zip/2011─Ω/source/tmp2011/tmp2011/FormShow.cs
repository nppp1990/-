﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace tmp2011
{
    public partial class FormShow : Form
    {
        public FormShow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 点击关闭按钮时候
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 对话框加载时候
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FormShow_Load(object sender, EventArgs e)
        {
            this.comboBox.SelectedIndex = -1;
            SqlManage.SetDataGridView(this.dataGridView);
        }

        /// <summary>
        /// 在ListView控件中显示信息
        /// </summary>
        /// <param name="tableString">表名</param>
        /// <param name="index">选中项目的索引号</param>
        private void ShowInfo(string tableString,int index)
        {
            this.listView.Clear();
            string sql = "select * from " + tableString;
            DataTable table = SqlManage.TableSelect(sql);
            ListViewItem lvi;
            string[] str = new string[5];
            if (index == 0)
            {
                this.listView.Columns.Add("车牌号");
                this.listView.Columns.Add("生产厂商");
                foreach (DataRow row in table.Rows)
                {
                    str[0] = row["BNO"].ToString();
                    str[1] = row["BCOMPANY"].ToString();
                    lvi = this.listView.Items.Add(str[0]);
                    lvi.SubItems.Add(str[1]);
                }
            }
            else if (index == 1)
            {
                this.listView.Columns.Add("员工号");
                this.listView.Columns.Add("姓名");
                this.listView.Columns.Add("性别");
                this.listView.Columns.Add("年龄");
                this.listView.Columns.Add("电话号码");
                foreach (DataRow row in table.Rows)
                {
                    str[0] = row["DNO"].ToString();
                    str[1] = row["DNAME"].ToString();
                    str[2] = row["DSEX"].ToString();
                    str[3] = row["DAGE"].ToString();
                    str[4] = row["DTELL"].ToString();

                    lvi = this.listView.Items.Add(str[0]);
                    for (int i = 1; i < 5; i++)
                    {
                        lvi.SubItems.Add(str[i]);
                    }
                }
            }
            else if (index == 2)
            {
                this.listView.Columns.Add("线路编号");
                this.listView.Columns.Add("始发站");
                this.listView.Columns.Add("终点站");
                this.listView.Columns.Add("距离");
                foreach (DataRow row in table.Rows)
                {
                    str[0] = row["LNO"].ToString();
                    str[1] = row["LSTART"].ToString();
                    str[2] = row["LEND"].ToString();
                    str[3] = row["LDISTANCE"].ToString();
                    lvi = this.listView.Items.Add(str[0]);
                    for (int i = 1; i < 4; i++)
                    {
                        lvi.SubItems.Add(str[i]);
                    }
                }
            }
            else if (index == 3)
            {
                this.listView.Columns.Add("线路编号");
                this.listView.Columns.Add("员工号");
                this.listView.Columns.Add("车牌号");
                this.listView.Columns.Add("发车时间");
                foreach (DataRow row in table.Rows)
                {
                    str[0] = row["LNO"].ToString();
                    str[1] = row["DNO"].ToString();
                    str[2] = row["BNO"].ToString();
                    str[3] = row["TIMESTART"].ToString();
                    lvi = this.listView.Items.Add(str[0]);
                    for (int i = 1; i < 4; i++)
                    {
                        lvi.SubItems.Add(str[i]);
                    }
                }
            }
            if (table.Rows.Count < 1)
            {
                MessageBox.Show("暂无记录");
            }
        }

        /// <summary>
        /// 在DataGridView控件中显示信息
        /// </summary>
        /// <param name="index">选中项目的索引号</param>
        private void ShowData(int index)
        {
            string sql = "";
            DataTable table = null;
            switch (index)
	        {
                case 0:
                    sql = "select BNO 车牌号,BCOMPANY as 生产厂商 from buses";
                    table = SqlManage.TableSelect(sql);
                    break;
                case 1:
                    sql = "select DNO as 员工号,DNAME as 姓名,DSEX as 性别,DAGE as 年龄,DTELL as 电话号码 from driver";
                    table = SqlManage.TableSelect(sql);
                    break;
                case 2:
                    sql = "select LNO as 线路编号,LSTART as 始发站,LEND as 终点站,LDISTANCE as 距离 from buslines";
                    table = SqlManage.TableSelect(sql);
                    break;
                case 3:
                    sql = "select LNO as 线路编号,DNO as 员工号,BNO as 车牌号,TIMESTART as 发车时间 from timetable";
                    table = SqlManage.TableSelect(sql);
                    break;
		        default:
                    break;
	        }
            this.dataGridView.DataSource = table;
        }
        
        /// <summary>
        /// 当ComboBox选中内容发生改变时候
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (this.comboBox.SelectedIndex)
            {
                case 0:
                    this.ShowInfo("buses",0);
                    this.ShowData(0);
                    break;
                case 1:
                    this.ShowInfo("driver",1);
                    this.ShowData(1);
                    break;
                case 2:
                    this.ShowInfo("buslines", 2);
                    this.ShowData(2);
                    break;
                case 3:
                    this.ShowInfo("timetable", 3);
                    this.ShowData(3);
                    break;
                default:
                    break;
            }
        }
    }
}
