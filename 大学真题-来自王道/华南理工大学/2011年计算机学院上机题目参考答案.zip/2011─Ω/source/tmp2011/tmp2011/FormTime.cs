﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace tmp2011
{
    public partial class FormTime : Form
    {
        public FormTime()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private bool JudTxt(TextBox t)
        {
            if (textBox3.Text.Trim().Length < 1)
	        {
                this.errorProvider.SetError(t,"输入内容");
                t.Focus();
                t.SelectAll();
                return false;
	        }
            else
            {
                return true;
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (!this.JudTxt(this.textBox1) || !this.JudTxt(this.textBox2) || !this.JudTxt(this.textBox3))
            {
                return;
            }
            string sql = string.Format("delete from timetable where LNO = '{0}'and DNO='{1}'and BNO='{2}'",
                this.textBox1.Text,this.textBox2.Text,this.textBox3.Text);
            SqlManage.TableChange(sql);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!this.JudTxt(this.textBox1) || !this.JudTxt(this.textBox2) || !this.JudTxt(this.textBox3))
            {
                return;
            }
            string sql = string.Format("insert into timetable values('{0}','{1}','{2}','{3}')",
                this.textBox1.Text,this.textBox2.Text,this.textBox3.Text,this.dateTimePicker1.Text.ToString());
            SqlManage.TableChange(sql);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!this.JudTxt(this.textBox1) || !this.JudTxt(this.textBox2) || !this.JudTxt(this.textBox3))
            {
                return;
            }
            string sql = string.Format("update timetable set TIMESTART = '{3}' where LNO = '{0}' and DNO='{1}'and BNO='{2}'",
                this.textBox1.Text, this.textBox2.Text, this.textBox3.Text, this.dateTimePicker1.Text.ToString());
            SqlManage.TableChange(sql);
        }
    }
}
