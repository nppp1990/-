﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace tmp2011
{
    class SqlManage
    {
        public static string cnnstring = "Server=wit;Database=tmp2011;Uid=sa;Pwd=123456;";
        public static SqlConnection cnn = null;

        /// <summary>
        /// 数据库查询操作
        /// </summary>
        /// <param name="sql">数据库语句</param>
        public static void TableChange(string sql)
        {
            try
            {
                SqlCommand cmd = new SqlCommand(sql,SqlManage.cnn);
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("操作成功");
                }
                else
                {
                    MessageBox.Show("操作失败!\n检查数据库是否有该记录");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// 数据库更新操作(包括插入、修改、删除)
        /// </summary>
        /// <param name="sql">数据库语句</param>
        /// <returns>返回查询结果</returns>
        public static DataTable TableSelect(string sql)
        {
            try
            {
                DataTable table = new DataTable();
                SqlDataAdapter sdp = new SqlDataAdapter(sql,SqlManage.cnn);
                sdp.Fill(table);
                return table;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }

        /// <summary>
        /// 设置DataGridView控件的属性
        /// </summary>
        /// <param name="d">控件名</param>
        public static void SetDataGridView(DataGridView d)
        {
            d.ReadOnly = true;
            d.AllowUserToAddRows = false;
            d.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        /// <summary>
        /// 判断TextBox控件是否输入了内容
        /// </summary>
        /// <param name="t">控件名</param>
        /// <returns>输入了内容发挥true</returns>
        public static bool JudTextBox(TextBox t)
        {
            return t.Text.Trim().Length > 0 ? true : false;
        }
    }
}
