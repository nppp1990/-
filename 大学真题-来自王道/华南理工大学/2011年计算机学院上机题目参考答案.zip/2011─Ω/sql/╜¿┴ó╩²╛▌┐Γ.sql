create database tmp2011
go