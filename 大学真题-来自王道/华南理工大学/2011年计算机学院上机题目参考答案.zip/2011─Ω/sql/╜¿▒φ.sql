use tmp2011
go

create table buses(
BNO char(4) primary key,
BCOMPANY varchar(120) not null default '�Ϻ�����'
);

create table driver(
DNO char(4) primary key,
DNAME varchar(50) not null,
DSEX char(2) not null check(DSEX in ('��','Ů')) default '��',
DAGE smallint check(DAGE >= 20 and DAGE <= 60),
DTELL varchar(15),
);

create table buslines(
LNO int primary key,
LSTART varchar(100) not null,
LEND varchar(100) not null,
LDISTANCE int not null default 0
);

create table timetable(
LNO int ,
DNO char(4),
BNO char(4),
TIMESTART datetime not null,
primary key(LNO,DNO,BNO),
  constraint fk_lno foreign key (LNO) references buslines(LNO),
  constraint fk_dno foreign key (DNO) references driver(DNO),
  constraint fk_bno foreign key (BNO) references buses(BNO)
);
go

