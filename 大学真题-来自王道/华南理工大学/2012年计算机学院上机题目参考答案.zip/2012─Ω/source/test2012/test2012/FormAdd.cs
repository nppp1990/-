﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace test2012
{
    public partial class FormAdd : Form
    {
        public FormAdd()
        {
            InitializeComponent();
        }

        private void FormAdd_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            e.Cancel = true;
            
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (this.txtNo.Text.Trim().Length == 0)
            {
                this.errorProvider.SetError(this.txtNo,"请输入教师号!");
                this.txtNo.Focus();
                this.txtNo.SelectAll();
                return;
            }
            if (this.txtName.Text.Trim().Length == 0)
            {
                this.errorProvider.SetError(this.txtName,"请输入教师姓名!");
                this.txtName.Focus();
                this.txtName.SelectAll();
                return;
            }
            if (this.txtAddress.Text.Trim().Length == 0)
            {
                this.errorProvider.SetError(this.txtAddress,"请输入所在地!");
                this.txtAddress.Focus();
                this.txtAddress.SelectAll();
                return;
            }

            string sql = string.Format("insert into EMPLOYEE values('{0}','{1}','{2}')",
                this.txtNo.Text,this.txtName.Text,this.txtAddress.Text);
            SqlCnn.TableChange(sql);
        }

        private void txtNo_TextChanged(object sender, EventArgs e)
        {
            if (this.txtNo.Text.Length > 0)
            {
                this.errorProvider.SetError(this.txtNo,"");
            }
            else
            {
                this.errorProvider.SetError(this.txtNo,"请输入教师号!");
                this.txtNo.Focus();
                this.txtNo.SelectAll();
            }
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            if (this.txtName.Text.Length > 0)
            {
                this.errorProvider.SetError(this.txtName, "");
            }
            else
            {
                this.errorProvider.SetError(this.txtName, "请输入教师姓名!");
                this.txtName.Focus();
                this.txtName.SelectAll();
            }
        }

        private void txtAdress_TextChanged(object sender, EventArgs e)
        {
            if (this.txtAddress.Text.Length > 0)
            {
                this.errorProvider.SetError(this.txtAddress, "");
            }
            else
            {
                this.errorProvider.SetError(this.txtAddress, "请输入教师号!");
                this.txtAddress.Focus();
                this.txtAddress.SelectAll();
            }
        }
    }
}
