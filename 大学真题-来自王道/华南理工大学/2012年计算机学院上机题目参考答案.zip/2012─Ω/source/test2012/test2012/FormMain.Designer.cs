﻿namespace test2012
{
    partial class FormMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.MenuAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuModify = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuShowAndDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuSearch = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuStatics = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuStaticsAndSearch = new System.Windows.Forms.ToolStripMenuItem();
            this.menuExit = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuAdd,
            this.MenuModify,
            this.MenuShowAndDelete,
            this.MenuSearch,
            this.MenuStatics,
            this.MenuStaticsAndSearch,
            this.menuExit});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(686, 25);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "menuStrip";
            // 
            // MenuAdd
            // 
            this.MenuAdd.Name = "MenuAdd";
            this.MenuAdd.Size = new System.Drawing.Size(92, 21);
            this.MenuAdd.Text = "员工信息添加";
            this.MenuAdd.Click += new System.EventHandler(this.MenuAdd_Click);
            // 
            // MenuModify
            // 
            this.MenuModify.Name = "MenuModify";
            this.MenuModify.Size = new System.Drawing.Size(92, 21);
            this.MenuModify.Text = "员工信息修改";
            this.MenuModify.Click += new System.EventHandler(this.MenuModify_Click);
            // 
            // MenuShowAndDelete
            // 
            this.MenuShowAndDelete.Name = "MenuShowAndDelete";
            this.MenuShowAndDelete.Size = new System.Drawing.Size(128, 21);
            this.MenuShowAndDelete.Text = "员工信息浏览及删除";
            this.MenuShowAndDelete.Click += new System.EventHandler(this.MenuShowAndDelete_Click);
            // 
            // MenuSearch
            // 
            this.MenuSearch.Name = "MenuSearch";
            this.MenuSearch.Size = new System.Drawing.Size(92, 21);
            this.MenuSearch.Text = "员工信息查询";
            this.MenuSearch.Click += new System.EventHandler(this.MenuSearch_Click);
            // 
            // MenuStatics
            // 
            this.MenuStatics.Name = "MenuStatics";
            this.MenuStatics.Size = new System.Drawing.Size(92, 21);
            this.MenuStatics.Text = "员工信息统计";
            this.MenuStatics.Click += new System.EventHandler(this.MenuStatics_Click);
            // 
            // MenuStaticsAndSearch
            // 
            this.MenuStaticsAndSearch.Name = "MenuStaticsAndSearch";
            this.MenuStaticsAndSearch.Size = new System.Drawing.Size(104, 21);
            this.MenuStaticsAndSearch.Text = "员工总工资查询";
            this.MenuStaticsAndSearch.Click += new System.EventHandler(this.MenuStaticsAndSearch_Click);
            // 
            // menuExit
            // 
            this.menuExit.Name = "menuExit";
            this.menuExit.Size = new System.Drawing.Size(44, 21);
            this.menuExit.Text = "退出";
            this.menuExit.Click += new System.EventHandler(this.menuExit_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(686, 382);
            this.Controls.Add(this.menuStrip);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "员工工作管理系统";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMain_FormClosing);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem MenuAdd;
        private System.Windows.Forms.ToolStripMenuItem MenuModify;
        private System.Windows.Forms.ToolStripMenuItem MenuShowAndDelete;
        private System.Windows.Forms.ToolStripMenuItem MenuSearch;
        private System.Windows.Forms.ToolStripMenuItem MenuStatics;
        private System.Windows.Forms.ToolStripMenuItem MenuStaticsAndSearch;
        private System.Windows.Forms.ToolStripMenuItem menuExit;
    }
}

