﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace test2012
{
    public partial class FormMain : Form
    {
        private FormAdd fadd = null;
        private FormModify fmodify = null;
        private FormShowAndDelete fsad = null;
        private FormSearch fsearch = null;
        private FormStatistics fstatistics = null;
        private FormStaticsAndSearch fstaSea = null;

        public FormMain()
        {
            InitializeComponent();
            try
            {
                //打开数据库连接
                SqlCnn.cnn.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message,"错误提示");
                Application.Exit();
            }
            
        }

        private void MenuAdd_Click(object sender, EventArgs e)
        {
            if (this.fadd == null)
            {
                this.fadd = new FormAdd();
                this.fadd.MdiParent = this;
            }
            this.fadd.Show();

        }

        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            SqlCnn.cnn.Close();//关闭数据库连接
        }

        private void menuExit_Click(object sender, EventArgs e)
        {
            Application.Exit();//退出应用程序
        }

        private void MenuModify_Click(object sender, EventArgs e)
        {
            if (this.fmodify == null)
            {
                this.fmodify = new FormModify();
                this.fmodify.MdiParent = this;
            }
            this.fmodify.Show();

        }

        private void MenuShowAndDelete_Click(object sender, EventArgs e)
        {
            if (this.fsad == null)
            {
                this.fsad = new FormShowAndDelete();
                this.fsad.MdiParent = this;
            }
            this.fsad.Show();
        }

        private void MenuSearch_Click(object sender, EventArgs e)
        {
            if (this.fsearch == null)
            {
                this.fsearch = new FormSearch();
                this.fsearch.MdiParent = this;
            }
            this.fsearch.Show();
        }

        private void MenuStatics_Click(object sender, EventArgs e)
        {
            if (this.fstatistics == null)
            {
                this.fstatistics = new FormStatistics();
                this.fstatistics.MdiParent = this;
            }
            this.fstatistics.Show();
        }

        private void MenuStaticsAndSearch_Click(object sender, EventArgs e)
        {
            if (this.fstaSea == null)
            {
                this.fstaSea = new FormStaticsAndSearch();
                this.fstaSea.MdiParent = this;
            }
            this.fstaSea.Show();
        }
    }
}
