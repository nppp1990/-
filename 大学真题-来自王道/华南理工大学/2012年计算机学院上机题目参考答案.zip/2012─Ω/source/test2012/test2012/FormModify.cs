﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace test2012
{
    public partial class FormModify : Form
    {
        public FormModify()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void FormModify_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            e.Cancel = true;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (this.txtName.Text.Trim().Length == 0)
            {
                this.errorProvider.SetError(this.txtName, "请输入教师姓名!");
                this.txtName.Focus();
                this.txtName.SelectAll();
                return;
            }
            if (this.txtAddress.Text.Trim().Length == 0)
            {
                this.errorProvider.SetError(this.txtAddress, "请输入所在地!");
                this.txtAddress.Focus();
                this.txtAddress.SelectAll();
                return;
            }

            string sql = string.Format("update EMPLOYEE set ENAME= '{1}',EADDRESS='{2}' where ENO = '{0}'",
                this.cboNo.Text, this.txtName.Text, this.txtAddress.Text);
            SqlCnn.TableChange(sql);
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            if (this.txtName.Text.Length > 0)
            {
                this.errorProvider.SetError(this.txtName, "");
            }
            else
            {
                this.errorProvider.SetError(this.txtName, "请输入教师姓名!");
                this.txtName.Focus();
                this.txtName.SelectAll();
            }
        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {
            if (this.txtAddress.Text.Length > 0)
            {
                this.errorProvider.SetError(this.txtAddress, "");
            }
            else
            {
                this.errorProvider.SetError(this.txtAddress, "请输入教师号!");
                this.txtAddress.Focus();
                this.txtAddress.SelectAll();
            }
        }

        private void FormModify_Load(object sender, EventArgs e)
        {
            string sql = "select ENO from EMPLOYEE where 1 = 1";
            DataTable table = SqlCnn.TableSelect(sql);
            string eno;
            foreach (DataRow row in table.Rows)
            {
                eno = (string)row["ENO"];
                this.cboNo.Items.Add(eno);
            }
            if (this.cboNo.Items.Count > 0)
                this.cboNo.SelectedIndex = 0;
        }
    }
}
