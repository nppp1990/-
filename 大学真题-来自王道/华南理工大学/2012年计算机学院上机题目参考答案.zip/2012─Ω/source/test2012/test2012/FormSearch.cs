﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace test2012
{
    public partial class FormSearch : Form
    {
        public FormSearch()
        {
            InitializeComponent();
        }

        private void btnCanCel_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
        private void FormSearch_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            e.Cancel = true;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (this.txtName.Text.Trim().Length < 1)
            {
                this.errorProvider.SetError(this.txtName,"请输入员工号!");
                this.txtName.Focus();
                this.txtName.SelectAll();
                return;
            }
            string sql = string.Format("select ENAME,CNAME,CADDRESS from EMPLOYEE,WORKS,COMPANY where EMPLOYEE.ENO = WORKS.ENO and WORKS.CNO = COMPANY.CNO and EMPLOYEE.ENAME = '{0}'",
                this.txtName.Text);
            DataTable table = SqlCnn.TableSelect(sql);
            if (table.Rows.Count > 0)
            {
                string ename, cname, caddress;
                ListViewItem lvi;
                foreach (DataRow row in table.Rows)
                {
                    ename = (string)row["ENAME"];
                    cname = (string)row["CNAME"];
                    caddress = (string)row["CADDRESS"];
                    lvi = this.listView.Items.Add(ename);
                    lvi.SubItems.Add(cname);
                    lvi.SubItems.Add(caddress);
                }
            }
            else
            {
                MessageBox.Show("暂无相关信息!");
            }
            
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            if (this.txtName.Text.Length >0)
            {
                this.errorProvider.SetError(this.txtName,"");
            }
            else
            {
                this.errorProvider.SetError(this.txtName,"请输入员工号!");
                this.txtName.Focus();
                this.txtName.SelectAll();
            }
        }

    }
}
