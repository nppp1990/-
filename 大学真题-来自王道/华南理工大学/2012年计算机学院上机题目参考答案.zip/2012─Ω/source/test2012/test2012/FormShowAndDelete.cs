﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace test2012
{
    public partial class FormShowAndDelete : Form
    {
        public FormShowAndDelete()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
           this.Hide();
        }

        private void FormShowAndDelete_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            e.Cancel = true;
        }

        private void ShowAll()
        {
            this.listView.Items.Clear();

            string sql = "select * from EMPLOYEE where 1 = 1";
            DataTable table = SqlCnn.TableSelect(sql);
            string eno, ename, eaddress;
            ListViewItem lvi;
            foreach (DataRow row in table.Rows)
            {
                eno = (string)row["ENO"];
                ename = (string)row["ENAME"];
                eaddress = (string)row["EADDRESS"];
                lvi = this.listView.Items.Add(eno);
                lvi.SubItems.Add(ename);
                lvi.SubItems.Add(eaddress);
            }
        }
        private void FormShowAndDelete_Load(object sender, EventArgs e)
        {
            this.ShowAll();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (this.listView.SelectedItems.Count < 1)
            {
                MessageBox.Show("还没有选中内容!");
                return ;
            }
            else
	        {
                string eno = this.listView.SelectedItems[0].SubItems[0].Text;
                string sql = string.Format("delete from EMPLOYEE where ENO = '{0}'",eno);
                SqlCnn.TableChange(sql);
                this.ShowAll();
	        }
        }

        private void btnReNew_Click(object sender, EventArgs e)
        {
            this.ShowAll();
        }
    }
}
