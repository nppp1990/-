﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace test2012
{
    public partial class FormStaticsAndSearch : Form
    {
        public FormStaticsAndSearch()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (this.txtCname.Text.Trim().Length < 1)
            {
                this.errorProvider.SetError(this.txtCname, "请输入公司名!");
                this.txtCname.Focus();
                this.txtCname.SelectAll();
                return;
            }
            this.DisplayAll();
        }

        private void txtCname_TextChanged(object sender, EventArgs e)
        {
            if (this.txtCname.Text.Length < 1)
            {
                this.errorProvider.SetError(this.txtCname,"请输入公司名!");
                this.txtCname.Focus();
                this.txtCname.SelectAll();
            }
            else
            {
                this.errorProvider.SetError(this.txtCname,"");
            }
        }

        private void DisplayAll()
        {
            string sql = string.Format("select ENO,ENAME from EMPLOYEE where ENO in (select WORKS.ENO from WORKS,COMPANY where COMPANY.CNO = WORKS.CNO and CNAME = '{0}')",
                this.txtCname.Text);
            DataTable table= SqlCnn.TableSelect(sql);
            string ename,eno;
            int total;
            ListViewItem lvi;
            foreach (DataRow row in table.Rows)
            {
                eno = (string)row["ENO"];
                ename = (string)row["ENAME"];
                string sqlnew = string.Format("select SUM(WOFFER) as TOTAL from WORKS where ENO = '{0}'", eno);
                DataTable tablenew = SqlCnn.TableSelect(sqlnew);
                total = (int)tablenew.Rows[0]["TOTAL"];
                lvi = this.listView.Items.Add(ename);
                lvi.SubItems.Add(total.ToString());
            }
        }
        private void FormStaticsAndSearch_Load(object sender, EventArgs e)
        {
            this.DisplayAll();
        }

        private void FormStaticsAndSearch_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            e.Cancel = true;
        }
    }
}
