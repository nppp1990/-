﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace test2012
{
    public partial class FormStatistics : Form
    {
        public FormStatistics()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void FormStatistics_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            e.Cancel = true;
        }

        private void DisplayAll()
        {
            this.listView.Items.Clear();

            //先查找出满足条件的员工的工号
            string sql = "select ENO from WORKS group by ENO having COUNT(CNO) > 1";
            DataTable table= SqlCnn.TableSelect(sql);
            string eno, ename;
            int woffer;
            ListViewItem lvi;
            foreach (DataRow row in table.Rows)
            {
                eno = (string)row["ENO"];
                //获取姓名
                string sqlnewname = string.Format("select ENAME from EMPLOYEE where ENO = '{0}'", eno);
                //获取该员工的总工资
                string sqlnewoffer = string.Format("select SUM(WOFFER) as TOTAL from EMPLOYEE,WORKS where EMPLOYEE.ENO = WORKS.ENO and WORKS.ENO = '{0}'",eno);
                DataTable tablenewname = SqlCnn.TableSelect(sqlnewname);
                DataTable tablenewoffer = SqlCnn.TableSelect(sqlnewoffer);
                ename = (string)tablenewname.Rows[0]["ENAME"];
                woffer = (int)tablenewoffer.Rows[0]["TOTAL"];
                lvi = this.listView.Items.Add(ename);
                lvi.SubItems.Add(woffer.ToString());
            }
        }
        private void FormStatistics_Load(object sender, EventArgs e)
        {
            this.DisplayAll();
        }

        private void btnRenew_Click(object sender, EventArgs e)
        {
            this.DisplayAll();
        }
    }
}
