﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace test2012
{
    public class SqlCnn
    {
        public static string cnnstring = "Server=wit;Database=emp;Uid=sa;Pwd=123456";
        public static SqlConnection cnn = new SqlConnection(SqlCnn.cnnstring);

        /// <summary>
        /// 对数据库表的增、删、改
        /// </summary>
        /// <param name="sql">要进行操作的sql语句</param>
        public static void TableChange(string sql)
        {
            try
            {
                SqlCommand cmd = new SqlCommand(sql, SqlCnn.cnn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("操作成功!");
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "错误提示");
                return;
            }

        }

        /// <summary>
        /// 对数据库表进行查找操作
        /// </summary>
        /// <param name="sql">sql语句</param>
        /// <returns></returns>
        public static DataTable TableSelect(string sql)
        {
            try
            {
                DataTable table = new DataTable();
                SqlDataAdapter sdp = new SqlDataAdapter(sql,SqlCnn.cnn);
                sdp.Fill(table);
                return table;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message,"错误提示");
                return null;
            }
        }
    }
}
