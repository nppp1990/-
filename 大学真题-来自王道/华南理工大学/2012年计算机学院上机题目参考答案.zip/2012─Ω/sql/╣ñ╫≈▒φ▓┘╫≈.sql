use emp

create table WORKS(
ENO varchar(5),
CNO varchar(5),
WOFFER int,
primary key(ENO,CNO),
foreign key (ENO) references EMPLOYEE(ENO),
foreign key (CNO) references COMPANY(CNO)
)

insert into WORKS values('E01','C01',2000);
insert into WORKS values('E02','C01',3000);
insert into WORKS values('E02','C02',3000);
insert into WORKS values('E03','C03',2000);
insert into WORKS values('E04','C01',4000);
insert into WORKS values('E04','C02',3000);
insert into WORKS values('E05','C03',2000);
