﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace tmp2013
{
    public partial class FormCourse : Form
    {
        public FormCourse()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string sql = string.Format("delete from COURSES where CNO = '{0}'",
                this.textBox1.Text);
            SqlManage.TableChange(sql);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = string.Format("insert into COURSES values('{0}','{1}','{2}')",
                this.textBox1.Text,this.textBox2.Text,this.textBox3.Text);
            SqlManage.TableChange(sql);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string sql = string.Format("update COURSES set CNAME = '{1}',CTIME = '{2}' where CNO = '{0}'",
                this.textBox1.Text,this.textBox2.Text,this.textBox3.Text);
            SqlManage.TableChange(sql);
        }
    }
}
