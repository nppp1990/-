﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace tmp2013
{
    public partial class FormDisplay : Form
    {
        public FormDisplay()
        {
            InitializeComponent();
        }

        private void FormDisplay_Load(object sender, EventArgs e)
        {
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.comboBox1.SelectedIndex = 0;
            string sql = "select TNO as 教师编号,TNAME as 教师姓名,TSEX as 性别 from TEACHERS";
            DataTable table = SqlManage.TableSelect(sql);
            this.dataGridView1.DataSource = table;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "";
            switch (this.comboBox1.SelectedIndex)
            {
                case 0:
                    sql = "select TNO as 教师编号,TNAME as 教师姓名,TSEX as 性别 from TEACHERS";
                    break;
                case 1:
                    sql = "select CNO as 课程标号,CNAME as 课程名,CTIME as 学时 from COURSES";
                    break;
                case 2:
                    sql = "select TNO as 教师编号,CNO as 课程标号,WYEAR as 年份,WSTAGE as 学期 from WORKS";
                    break;
                default:
                    break;
            }
            DataTable table = SqlManage.TableSelect(sql);
            this.dataGridView1.DataSource = table;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
