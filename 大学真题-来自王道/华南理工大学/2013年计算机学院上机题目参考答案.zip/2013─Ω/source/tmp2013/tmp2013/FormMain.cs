﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace tmp2013
{
    public partial class FormMain : Form
    {
        public string sql = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=emp;Data Source=hubo-pc";

        public FormMain()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormTeacher ft = new FormTeacher();
            ft.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormWorks fw = new FormWorks();
            fw.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormCourse fc = new FormCourse();
            fc.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FormDisplay fd = new FormDisplay();
            fd.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FormSearch fs = new FormSearch();
            fs.Show();
        }
    }
}
