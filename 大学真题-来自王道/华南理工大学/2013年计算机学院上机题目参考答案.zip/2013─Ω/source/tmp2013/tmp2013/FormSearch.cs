﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace tmp2013
{
    public partial class FormSearch : Form
    {
        public FormSearch()
        {
            InitializeComponent();
        }

        private void FormSearch_Load(object sender, EventArgs e)
        {
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            //初始化教师编号
            string sql = "select TNO from TEACHERS";
            DataTable table = SqlManage.TableSelect(sql);
            string tno;
            foreach (DataRow row in table.Rows)
            {
                tno = row["TNO"].ToString();
                this.comboBox1.Items.Add(tno);
            }
            if (table.Rows.Count > 0)
            {
                this.comboBox1.SelectedIndex = 0;
            }

            //初始化教师姓名
            string sql_name = "select TNAME from TEACHERS";
            table.Clear();
            table = SqlManage.TableSelect(sql_name);
            string tname;
            foreach (DataRow row in table.Rows)
            {
             tname = row["TNAME"].ToString();
             this.comboBox2.Items.Add(tname);
            }
            if (table.Rows.Count > 0)
            {
                this.comboBox2.SelectedIndex = 0;
            }

            //初始化学时
            string sql_time = "select distinct CTIME from COURSES";
            table.Clear();
            table = SqlManage.TableSelect(sql_time);
            string time;
            foreach (DataRow row in table.Rows)
            {
                time = row["CTIME"].ToString();
                this.comboBox3.Items.Add(time);
            }
            if (table.Rows.Count > 0)
            {
                this.comboBox3.SelectedIndex = 0;
            }

            //初始化年份
            string sql_year = "select distinct WYEAR from WORKS";
            table.Clear();
            table = SqlManage.TableSelect(sql_year);
            string year;
            
            foreach (DataRow row in table.Rows)
            {
                year = row["WYEAR"].ToString();
                this.comboBox4.Items.Add(year);
            }
            if (table.Rows.Count > 0)
            {
                this.comboBox4.SelectedIndex = 0;
            }

            //初始化课程数
            if (this.comboBox5.Items.Count > 0)
            {
                this.comboBox5.SelectedIndex = 0;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioButton1.Checked)
            {
                this.comboBox1.Enabled = true;
            }
            else
            {
                this.comboBox1.Enabled = false;
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioButton2.Checked)
            {
                this.comboBox2.Enabled = true;
            }
            else
            {
                this.comboBox2.Enabled = false;
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioButton3.Checked)
            {
                this.comboBox3.Enabled = true;
            }
            else
            {
                this.comboBox3.Enabled = false;
            }
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioButton4.Checked)
            {
                this.comboBox4.Enabled = true;
            }
            else
            {
                this.comboBox4.Enabled = false;
            }
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            if (this.radioButton5.Checked)
            {
                this.comboBox5.Enabled = true;
            }
            else
            {
                this.comboBox5.Enabled = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "";
            if (this.radioButton1.Checked)
            {
                sql = string.Format("select TNO as 教师编号,TNAME as 教师姓名,TSEX as 性别 from TEACHERS where TNO = '{0}'",
                    this.comboBox1.Text);
            }
            else if (this.radioButton2.Checked)
            {
                sql = string.Format("select TNO as 教师编号,TNAME as 教师姓名,TSEX as 性别 from TEACHERS where TNAME = '{0}'",
                    this.comboBox2.Text);
            }
            else if (this.radioButton3.Checked)
            {
                sql = string.Format("select CTIME as 年份,TNAME as 教师姓名,CNAME as 所授课程 from TEACHERS,WORKS,COURSES where COURSES.CNO = WORKS.CNO and WORKS.TNO = TEACHERS.TNO and CTIME = '{0}'",
                    this.comboBox3.Text);
            }
            else if (this.radioButton4.Checked)
            {
                sql = string.Format("select WYEAR as 年份,TNAME as 教师姓名,CNAME as 所授课程 from TEACHERS,WORKS,COURSES where COURSES.CNO = WORKS.CNO and WORKS.TNO = TEACHERS.TNO and WYEAR = '{0}'",
                    this.comboBox4.Text);
            }
            else
            {
                sql = "select TNAME as 教师名,CNAME as 课程名 from TEACHERS,COURSES,WORKS";
                sql += " where TEACHERS.TNO = WORKS.TNO and WORKS.CNO = COURSES.CNO and WORKS.TNO in";
                sql += " (select TNO from WORKS group by TNO having COUNT(CNO) >=2);";
            }

            DataTable table = SqlManage.TableSelect(sql);
            if (table.Rows.Count > 0)
            {
                this.dataGridView1.DataSource = table;
            }
            else
            {
                MessageBox.Show("没有相关内容");
            }
        }
    }
}
