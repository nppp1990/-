﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace tmp2013
{
    public partial class FormTeacher : Form
    {
        public FormTeacher()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string sql = string.Format("delete from TEACHERS where TNO = '{0}'",
                this.textBox1.Text);
            SqlManage.TableChange(sql);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sex = "";
            if (this.radioButton1.Checked)
            {
                sex = "男";
            }
            else
            {
                sex = "女";
            }
            string sql = string.Format("insert into TEACHERS values('{0}','{1}','{2}')",
                this.textBox1.Text,this.textBox2.Text,sex);
            SqlManage.TableChange(sql);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string sex = this.radioButton1.Checked ? "男" : "女";
            string sql = string.Format("update TEACHERS set TNAME = '{1}',TSEX = '{2}' where TNO = '{0}'",
                this.textBox1.Text,this.textBox2.Text,sex);
            SqlManage.TableChange(sql);
        }
    }
}
