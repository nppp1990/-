﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace tmp2013
{
    public partial class FormWorks : Form
    {
        public FormWorks()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormWorks_Load(object sender, EventArgs e)
        {

            for (int index = 2015; index >= 2000; index--)
            {
                this.comboBox1.Items.Add(index.ToString());   
            }
            this.comboBox1.SelectedIndex = 0;

            string[] year = new string[4] { "春", "夏", "秋", "冬" };
            foreach (string item in year)
            {
                this.comboBox2.Items.Add(item);
            }
            this.comboBox2.SelectedIndex = 0;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string sql = string.Format("delete from WORKS where TNO ='{0}' and CNO = '{1}'",
                this.textBox1.Text,this.textBox2.Text);
            SqlManage.TableChange(sql);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = string.Format("insert into WORKS values('{0}','{1}','{2}','{3}')",
                this.textBox1.Text, this.textBox2.Text, this.comboBox1.Text, this.comboBox2.Text);
            SqlManage.TableChange(sql);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string sql = string.Format("update WORKS set WYEAR = '{2}',WSTAGE = '{3}' where TNO = '{0}' and CNO = '{1}'",
                this.textBox1.Text,this.textBox2.Text,this.comboBox1.Text,this.comboBox2.Text);
            SqlManage.TableChange(sql);
        }
    }
}
