﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace tmp2013
{
    static class Program
    {
       // string cnnstring = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=emp;Data Source=hubo-pc";
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            try
            {
                SqlManage.cnn = new SqlConnection(SqlManage.cnnstring);
                SqlManage.cnn.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
                return;
            }
            Application.Run(new FormMain());

            SqlManage.cnn.Close();
        }
    }
}
