use test

create table WORKS(
TNO varchar(5),
CNO varchar(5),
WYEAR char(4),
WSTAGE char(2),
primary key(TNO,CNO),
foreign key (TNO) references TEACHERS(TNO),
foreign key (CNO) references COURSES(CNO)
);

insert into WORKS values('T01','C01','2010','��');
insert into WORKS values('T01','C02','2010','��');
insert into WORKS values('T02','C01','2011','��');
insert into WORKS values('T03','C01','2011','��');
insert into WORKS values('T04','C02','2011','��');
insert into WORKS values('T04','C03','2010','��');
insert into WORKS values('T04','C04','2012','��');
